## Descripción
…

## Relacionado con
Semana/Hito: …

## Checklist
- [ ] Pruebas locales OK
- [ ] CI pasa
- [ ] Documentación actualizada
