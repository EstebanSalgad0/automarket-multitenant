---
name: Reporte de bug
about: Algo no funciona como se espera
---

**Descripción**
¿Qué pasó?

**Para reproducir**
Pasos…

**Esperado**
…

**Extras**
Logs, capturas, etc.
