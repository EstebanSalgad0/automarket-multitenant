---
name: Solicitud de mejora
about: Proponer una nueva funcionalidad
---

**Problema relacionado**
…

**Propuesta**
…

**Notas adicionales**
…
