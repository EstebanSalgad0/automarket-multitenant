# Código de Conducta (resumen)

- Respeto y colaboración.
- Comunicación clara; no spam.
- Reporta incidentes al docente.
