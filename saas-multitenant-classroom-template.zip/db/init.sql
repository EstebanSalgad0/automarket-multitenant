-- Multitenant schema (PostgreSQL)
-- Extensiones
create extension if not exists pgcrypto;

-- Tenants
create table if not exists tenants (
  id uuid primary key default gen_random_uuid(),
  nombre text not null,
  created_at timestamptz not null default now()
);

-- Usuarios globales
create table if not exists usuarios (
  id uuid primary key default gen_random_uuid(),
  email text unique not null,
  nombre text not null,
  created_at timestamptz not null default now()
);

-- Membresía de usuarios por tenant
create table if not exists tenant_usuarios (
  tenant_id uuid not null references tenants(id) on delete cascade,
  usuario_id uuid not null references usuarios(id) on delete cascade,
  rol text not null check (rol in ('admin','editor','viewer')),
  primary key (tenant_id, usuario_id)
);

-- Tabla de dominio de ejemplo
create table if not exists productos (
  tenant_id uuid not null references tenants(id) on delete cascade,
  id uuid not null default gen_random_uuid(),
  nombre text not null,
  precio numeric(12,2) not null default 0,
  stock integer not null default 0,
  created_at timestamptz not null default now(),
  primary key (tenant_id, id)
);

-- Índices
create index if not exists idx_productos_tenant_nombre on productos (tenant_id, nombre);

-- Datos de ejemplo (2 tenants)
insert into tenants (id, nombre) values
  ('11111111-1111-1111-1111-111111111111', 'Tenant Alfa')
  on conflict (id) do nothing;

insert into tenants (id, nombre) values
  ('22222222-2222-2222-2222-222222222222', 'Tenant Beta')
  on conflict (id) do nothing;

insert into usuarios (id, email, nombre) values
  ('aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'admin@alfa.tld', 'Admin Alfa')
  on conflict (id) do nothing;

insert into usuarios (id, email, nombre) values
  ('bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 'admin@beta.tld', 'Admin Beta')
  on conflict (id) do nothing;

insert into tenant_usuarios (tenant_id, usuario_id, rol) values
  ('11111111-1111-1111-1111-111111111111', 'aaaaaaaa-aaaa-aaaa-aaaa-aaaaaaaaaaaa', 'admin')
  on conflict do nothing;

insert into tenant_usuarios (tenant_id, usuario_id, rol) values
  ('22222222-2222-2222-2222-222222222222', 'bbbbbbbb-bbbb-bbbb-bbbb-bbbbbbbbbbbb', 'admin')
  on conflict do nothing;

insert into productos (tenant_id, nombre, precio, stock) values
  ('11111111-1111-1111-1111-111111111111', 'Producto A1', 1000, 10),
  ('11111111-1111-1111-1111-111111111111', 'Producto A2', 2500, 5),
  ('22222222-2222-2222-2222-222222222222', 'Producto B1', 1500, 7),
  ('22222222-2222-2222-2222-222222222222', 'Producto B2', 3800, 3);

-- (Opcional) Bosquejo RLS para siguientes sprints
-- alter table productos enable row level security;
-- create policy productos_por_tenant on productos
--   using (tenant_id = current_setting('app.tenant_id')::uuid);
