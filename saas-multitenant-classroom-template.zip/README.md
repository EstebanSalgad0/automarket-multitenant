# SaaS Multitenant con Docker — Plantilla (GitHub Classroom)

Plantilla base para el **proyecto SaaS multitenant** de Ingeniería Civil Informática.
Incluye esquema de base de datos con `tenant_id`, Docker Compose (Postgres + Adminer), CI mínimo y
plantillas de documentación/entregas.

> **Profesor:** use este repo como *template* en GitHub Classroom.  
> **Estudiantes:** completen los campos marcados como TODO y sigan el cronograma.

---

## Información del equipo (TODO)
- **Sección/Curso:** …
- **Integrante(s):** …
- **Email(s):** …
- **Nombre del proyecto (SaaS):** …
- **Descripción breve (3–5 líneas):** …

## Cronograma de Entregas
- **Semana 1 — Presentación de Idea**: Thursday 04/09/2025 (23:59 CLT)
- **Semana 2 — Modelo de Datos + Prueba de Tenant**: Thursday 11/09/2025 (23:59 CLT)
- **Semana 3 — API Base**: Thursday 25/09/2025 (23:59 CLT)
- **Semana 4 — Auth + Roles por Tenant**: Thursday 02/10/2025 (23:59 CLT)
- **Semana 5 — MVP Navegable**: Thursday 09/10/2025 (23:59 CLT)
- **Entrega Final — Proyecto**: Thursday 16/10/2025 (23:59 CLT)

> **Semana del 18/09:** sin entrega (Fiestas Patrias).

> Todas las entregas se publican con un **tag/release** `v0.X` + **changelog** breve (ver `docs/changelog.md`).

## Reglas técnicas mínimas
- `tenant_id` en todas las tablas de dominio (**aislamiento por tenant**).
- PK compuesta `(tenant_id, id)` o UUID + índice `(tenant_id, id)`.
- Consultas siempre **filtradas por `tenant_id`** (middleware/DAO).
- `docker compose up` debe levantar **DB + Adminer**.
- Variables en `.env` (no subir secretos).
- **Auth/roles** y bosquejo de **RLS** para Postgres desde la Semana 4.

## Quick Start
```bash
# 1) Copiar .env de ejemplo
cp .env.example .env

# 2) Levantar servicios
docker compose up -d

# 3) Adminer
#    URL: http://localhost:8080
#    Sistema: PostgreSQL | Servidor: db | Usuario: ${'{'}POSTGRES_USER{'}'}
#    Contraseña: ${'{'}POSTGRES_PASSWORD{'}'} | Base: ${'{'}POSTGRES_DB{'}'}
```

## Estructura
```
.
├── .github/workflows/ci.yml          # CI: valida init.sql contra Postgres
├── .gitignore
├── .env.example
├── CODE_OF_CONDUCT.md
├── CONTRIBUTING.md
├── LICENSE
├── README.md
├── docker-compose.yml
├── db/
│   ├── init.sql                      # Esquema + datos de ejemplo (2 tenants)
│   └── seed/                         # (opcional) scripts adicionales
├── docs/
│   ├── one-pager.md                  # Plantilla one-pager
│   ├── pitch-outline.md              # Guía pitch (8–12 slides)
│   ├── architecture-c4.md            # Esqueleto C4 L1–L2
│   ├── rubric.md                     # Criterios de evaluación
│   ├── classroom-setup.md            # Pasos para GitHub Classroom
│   ├── demo-checklist.md             # Checklist demo
│   ├── changelog.md                  # Cambios por semana
│   └── weekly-deliverables/
│       ├── semana-1.md
│       ├── semana-2.md
│       ├── semana-3.md
│       ├── semana-4.md
│       ├── semana-5.md
│       └── final.md
├── scripts/
│   ├── psql.sh                       # Conectar a la DB del compose
│   └── verify_tenant.sql             # Consulta de ejemplo (scoping)
├── api/README.md                     # Borrador de endpoints
└── app/README.md                     # Placeholder de frontend
```

## Evaluación (100 pts)
- Sem. 1: Idea y evidencia (15 pts)
- Sem. 2: Modelo de datos multitenant (20 pts)
- Sem. 3: API con scoping por tenant (15 pts)
- Sem. 4: Auth/roles + diseño de aislamiento (15 pts)
- Sem. 5: MVP navegable (20 pts)
- Final: Entrega + docs + demo (15 pts)

**Penalización:** −10% por día hábil (máx. 3). Sin entrega final = reprobado salvo justificación formal.

---

## Seguridad y buenas prácticas
- No subir secretos ni datos personales reales.
- Usar usuarios/roles mínimos en DB.
- Registrar **riesgos** y **próximos pasos** en cada entrega (`docs/weekly-deliverables`).

¡Éxitos y a construir! 🚀
