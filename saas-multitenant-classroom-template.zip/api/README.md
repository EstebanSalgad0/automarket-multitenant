# API — Borrador

Defina endpoints principales (ejemplo):
- `POST /auth/login`
- `GET /{tenantId}/productos`
- `POST /{tenantId}/productos`
- `PUT /{tenantId}/productos/{id}`
- `DELETE /{tenantId}/productos/{id}`

**Nota:** toda consulta debe filtrar por `tenant_id`.
