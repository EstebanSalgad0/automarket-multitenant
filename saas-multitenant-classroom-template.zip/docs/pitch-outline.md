# Pitch (8–12 diapositivas)

1. Título (nombre + slogan)
2. Problema (evidencia/impacto)
3. Usuarios y contexto (personas, flujo as-is)
4. Propuesta de valor (beneficios)
5. MVP (priorización MoSCoW)
6. Arquitectura de alto nivel (C4 L1–L2)
7. Modelo de datos multitenant
8. Seguridad y compliance
9. Plan técnico (Docker, CI/CD, entornos)
10. Roadmap, riesgos, métricas
11. Demo mínima (DB + Adminer)
12. Cierre
