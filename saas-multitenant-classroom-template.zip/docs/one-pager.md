# One-Pager (Plantilla)

**Nombre del SaaS:**  
**Problema (3–5 líneas):**  
**Usuarios/Contexto:**  
**Propuesta de valor (bullets):**  
**MVP (3–5 casos de uso):**  
**Arquitectura (resumen):** Front, API, DB, servicios externos.  
**Multitenancy:** `tenant_id`, PK/índices, (RLS futuro).  
**Seguridad:** Auth, autorización por tenant, secretos.  
**Stack & Docker:** servicios del compose.  
**Roadmap (2–3 sprints):**  
**Riesgos y mitigaciones:**  
**Métricas de éxito:**  
