# Changelog (semanal)
- **v0.1 (Semana 1):** Idea + repo + compose + init.sql base.
- **v0.2 (Semana 2):** Modelo de datos completo + pruebas de tenant.
- **v0.3 (Semana 3):** API base CRUD (multitenant).
- **v0.4 (Semana 4):** Auth + roles + bosquejo RLS.
- **v0.5 (Semana 5):** MVP navegable end-to-end.
- **v1.0 (Final):** Entrega completa + video demo + docs.
