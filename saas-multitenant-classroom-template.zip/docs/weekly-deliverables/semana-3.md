# Semana 3 — API Base

**Entregables:**
- CRUD de 1–2 entidades con scoping por tenant
- Colección HTTP (Insomnia/Postman)

**Tag:** `v0.3`
