# Semana 1 — Presentación de Idea

**Entregables:**
- Pitch (8–12 slides), One-pager
- Repo con README, docker-compose, db/init.sql (tenant_id + 1 tabla)

**Checklist:**
- [ ] Problema + evidencia
- [ ] Personas y contexto
- [ ] MVP (3–5)
- [ ] Arquitectura alto nivel
- [ ] Script SQL con tenant_id
- [ ] Compose OK

**Tag:** `v0.1`
