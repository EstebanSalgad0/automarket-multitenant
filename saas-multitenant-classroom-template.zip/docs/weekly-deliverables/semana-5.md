# Semana 5 — MVP Navegable

**Entregables:**
- Front mínimo (3–5 casos de uso)
- Flujo end-to-end (UI → API → DB) por tenant
- Logs básicos + `.env` documentado

**Tag:** `v0.5`
