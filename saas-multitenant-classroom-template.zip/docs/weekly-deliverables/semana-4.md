# Semana 4 — Auth + Roles por Tenant

**Entregables:**
- Autenticación + autorización (tenant_usuarios)
- Roles (`admin`, `editor`, `viewer`)
- Bosquejo de RLS (si Postgres)

**Tag:** `v0.4`
