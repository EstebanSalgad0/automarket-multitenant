# Entrega Final — 16/10/2025

**Entregables:**
- MVP funcionando
- README definitivo (setup/uso)
- Diagrama de arquitectura (C4 L1–L2)
- Video demo (5–7 min)
- Checklist de seguridad y pruebas
- Issues cerradas/abiertas

**Tag:** `v1.0`
