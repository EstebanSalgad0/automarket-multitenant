# Semana 2 — Modelo de Datos + Prueba de Tenant

**Entregables:**
- Esquema completo multitenant
- Datos semilla con **2 tenants**
- Consultas filtradas por `tenant_id`

**Tag:** `v0.2`
