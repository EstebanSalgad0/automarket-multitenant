# Arquitectura (C4 L1–L2)

- **Contexto (L1):** Usuarios, SaaS, sistemas externos.
- **Contenedores (L2):** Web/App, API, DB, almacenamiento, correo, monitoreo.
- Señalar *boundaries*, auth, y aislamiento por tenant.
- Diagrama (puede ser PlantUML, Draw.io, Excalidraw, Figma).
