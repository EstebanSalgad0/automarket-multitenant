# Checklist de Demo

- [ ] `docker compose up` ejecuta sin errores.
- [ ] Adminer accesible en `http://localhost:8080`.
- [ ] Esquema creado; tablas con `tenant_id`.
- [ ] Datos de ejemplo visibles por tenant.
- [ ] Consulta/endpoint demuestra aislamiento por tenant.
