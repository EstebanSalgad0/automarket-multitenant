# GitHub Classroom — Pasos sugeridos (Docente)

1. Cree/abra su Classroom y una *roster* de alumnos.
2. Haga clic en **New assignment** → tipo **Individual**.
3. En **Repository** seleccione **Use a template** y apunte a este repo.
4. **Deadline:** jueves 23:59 (CLT) por semana; final: **16/10/2025 23:59**.
5. Naming: `saas-2025-{github-username}`.
6. Visibilidad: **Private**; **Feedback** activado.
7. Permitir *late submissions* (penalización manual).
8. Pruebe aceptando la tarea con una cuenta de prueba.
9. Monitoree el estado desde el tablero; use *autograding* más adelante si agrega tests.
