# Rúbrica (100 pts)

- Semana 1: Idea y evidencia — **15 pts**
- Semana 2: Modelo de datos multitenant — **20 pts**
- Semana 3: API con scoping por tenant — **15 pts**
- Semana 4: Auth/roles + aislamiento — **15 pts**
- Semana 5: MVP navegable — **20 pts**
- Final: Entrega + docs + demo — **15 pts**

**Penalizaciones:** atraso −10%/día hábil (máx. 3).
