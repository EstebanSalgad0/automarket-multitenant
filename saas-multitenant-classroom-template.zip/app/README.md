# App (Frontend) — Placeholder

- Tecnologías sugeridas: React/Next.js + Fetch/axios.
- Rutas mínimas: login, dashboard, productos (CRUD).
- Mostrar el `tenant` activo y respetar permisos por rol.
