# Contribución

- Trabajar con ramas por feature: `feat/x`, `fix/y`.
- PRs con descripción y referencia a semana/hito.
- Etiquetar entregas: `v0.X` (semana) y `v1.0` (final).
- No subir secretos ni datos personales reales.
